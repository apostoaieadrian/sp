
public class Capitol {
	public Capitol() {
		
	}
}
