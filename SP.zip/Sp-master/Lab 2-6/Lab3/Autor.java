
public class Autor {
private String numeAutor;
	public Autor(String numeAutor) {
		this.numeAutor=numeAutor;
	}
}
