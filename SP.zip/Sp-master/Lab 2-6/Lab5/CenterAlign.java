
public class CenterAlign implements AlignStrategy {
	String text;
	
	public void printAlign(String text) {
		System.out.println("\t \t \t " + text);
		// TODO Auto-generated method stub
		
	}

}
