
public interface AlignStrategy {
	public void printAlign(String text);
}
