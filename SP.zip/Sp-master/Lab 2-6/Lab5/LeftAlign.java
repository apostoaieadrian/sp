
public class LeftAlign implements AlignStrategy{
	String text;
	
	public void printAlign(String text) {
		System.out.println("\t" + text);
		// TODO Auto-generated method stub
		
	}

}
